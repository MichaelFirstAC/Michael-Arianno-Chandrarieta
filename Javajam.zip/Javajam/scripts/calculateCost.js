function calculateCost() {
    const coffeeTypes = {
        1: { name: "Just Java", price: 2.00 },
        2: { name: "Cafe au Lait", singlePrice: 2.00, doublePrice: 3.00 },
        3: { name: "Iced Cappuccino", singlePrice: 4.75, doublePrice: 6.00 },
        4: { name: "Cafe Mocha", singlePrice: 3.25, doublePrice: 4.25 },
        5: { name: "Cafe Latte", singlePrice: 3.75, doublePrice: 4.75 },
        6: { name: "Pure Espresso", singlePrice: 3.50, doublePrice: 6.00 }
    };

    // Get the coffee type from the user
    const coffeeTypeId = parseInt(prompt("Enter the Coffee Type (1-6):\n1. Just Java\n2. Cafe au Lait\n3. Iced Cappuccino\n4. Cafe Mocha\n5. Cafe Latte\n6. Pure Espresso"));

    // Validate the input
    if (isNaN(coffeeTypeId) || coffeeTypeId < 1 || coffeeTypeId > 6) {
        alert("Invalid Coffee Type. Please enter a number between 1 and 6.");
        return;
    }

    const selectedCoffee = coffeeTypes[coffeeTypeId];

    // For Just Java, we only need quantity
    if (coffeeTypeId === 1) {
        const quantity = parseInt(prompt(`How many cups of ${selectedCoffee.name} would you like?`));
        if (isNaN(quantity) || quantity < 1) {
            alert("Invalid quantity. Please enter a positive number.");
            return;
        }
        const cost = selectedCoffee.price * quantity;
        alert(`The total cost for ${quantity} cup(s) of ${selectedCoffee.name} is $${cost.toFixed(2)}`);
    } else {
        // For other coffee types, we need to know if it's single or double
        const size = prompt(`Would you like a single or double ${selectedCoffee.name}? (Enter 'single' or 'double')`).toLowerCase();
        if (size !== 'single' && size !== 'double') {
            alert("Invalid size. Please enter 'single' or 'double'.");
            return;
        }
        const price = size === 'single' ? selectedCoffee.singlePrice : selectedCoffee.doublePrice;
        const quantity = parseInt(prompt(`How many ${size} ${selectedCoffee.name} would you like?`));
        if (isNaN(quantity) || quantity < 1) {
            alert("Invalid quantity. Please enter a positive number.");
            return;
        }
        const cost = price * quantity;
        alert(`The total cost for ${quantity} ${size} ${selectedCoffee.name} is $${cost.toFixed(2)}`);
    }
}